# single-page-app-vanilla-js

Taken from my YouTube Tutorial:
https://www.youtube.com/watch?v=6BozpmSjk-Y
